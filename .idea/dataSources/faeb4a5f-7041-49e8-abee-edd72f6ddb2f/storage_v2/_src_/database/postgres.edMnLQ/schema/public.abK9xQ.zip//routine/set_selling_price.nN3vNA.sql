create function set_selling_price() returns trigger
    language plpgsql
as
$$
BEGIN
  DECLARE
    sp NUMERIC(13, 4);
  BEGIN
    SELECT selling_price INTO sp
    FROM "Store_Product"
    WHERE UPC = NEW.UPC;

    NEW.selling_price := sp;
    RETURN NEW;
  END;
END;
$$;

alter function set_selling_price() owner to postgres;

grant execute on function set_selling_price() to anon;

grant execute on function set_selling_price() to authenticated;

grant execute on function set_selling_price() to service_role;

