create function update_check_sum_total_after_delete() returns trigger
    language plpgsql
as
$$
DECLARE
    adjusted_price NUMERIC(13, 4);
    card_percent INT;
BEGIN
  -- Retrieve the percentage from Customer_Card if card_number is present in Check
  SELECT cc.percent INTO card_percent
  FROM "Check" c
  LEFT JOIN "Customer_Card" cc ON c.card_number = cc.card_number
  WHERE c.check_number = OLD.check_number;

  -- Adjust selling price based on customer card percentage
  IF card_percent IS NOT NULL THEN
    adjusted_price := OLD.selling_price - (OLD.selling_price * card_percent / 100);
  ELSE
    adjusted_price := OLD.selling_price;
  END IF;

  -- Update the sum_total in Check table by subtracting the adjusted selling price
  -- multiplied by the number of products in the sale
  UPDATE "Check"
  SET sum_total = sum_total - (adjusted_price * OLD.product_number)
  WHERE check_number = OLD.check_number;

  RETURN OLD;
END;
$$;

alter function update_check_sum_total_after_delete() owner to postgres;

grant execute on function update_check_sum_total_after_delete() to anon;

grant execute on function update_check_sum_total_after_delete() to authenticated;

grant execute on function update_check_sum_total_after_delete() to service_role;

