create function set_promotional_price() returns trigger
    language plpgsql
as
$$
BEGIN
  DECLARE
    base_price NUMERIC(13, 4);
  BEGIN
    SELECT selling_price INTO base_price
    FROM "Store_Product"
    WHERE UPC = NEW.UPC_prom;

    NEW.selling_price = base_price * 0.8;
    RETURN NEW;
  END;
END;
$$;

alter function set_promotional_price() owner to postgres;

grant execute on function set_promotional_price() to anon;

grant execute on function set_promotional_price() to authenticated;

grant execute on function set_promotional_price() to service_role;

