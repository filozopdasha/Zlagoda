create function calculate_pdv() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.val := NEW.sum_total * 0.2;
  RETURN NEW;
END;
$$;

alter function calculate_pdv() owner to postgres;

grant execute on function calculate_pdv() to anon;

grant execute on function calculate_pdv() to authenticated;

grant execute on function calculate_pdv() to service_role;

