create function update_check_sum_total() returns trigger
    language plpgsql
as
$$
DECLARE
    adjusted_price NUMERIC(13, 4);
    card_percent INT;
BEGIN
  -- Retrieve the percentage from Customer_Card if card_number is present in Check
  SELECT cc.percent INTO card_percent
  FROM "Check" c
  LEFT JOIN "Customer_Card" cc ON c.card_number = cc.card_number
  WHERE c.check_number = NEW.check_number;

  -- Adjust selling price based on customer card percentage
  IF card_percent IS NOT NULL THEN
    adjusted_price := NEW.selling_price - (NEW.selling_price * card_percent / 100);
  ELSE
    adjusted_price := NEW.selling_price;
  END IF;

  -- Check if the UPC already exists in Check table
  IF EXISTS (
    SELECT 1 FROM "Check" WHERE upc = NEW.upc
  ) THEN
    -- If the UPC exists, update the product number of the existing sale
    UPDATE "Sale"
    SET product_number = product_number + NEW.product_number
    WHERE upc = NEW.upc AND check_number != NEW.check_number; -- Exclude the current sale

    -- Adjust the sum_total in Check table accordingly
    UPDATE "Check"
    SET sum_total = sum_total + (adjusted_price * NEW.product_number)
    WHERE check_number = NEW.check_number;
  ELSE
    -- If the UPC doesn't exist, proceed as usual
    UPDATE "Check"
    SET sum_total = sum_total + (adjusted_price * NEW.product_number)
    WHERE check_number = NEW.check_number;
  END IF;

  RETURN NEW;
END;
$$;

alter function update_check_sum_total() owner to postgres;

grant execute on function update_check_sum_total() to anon;

grant execute on function update_check_sum_total() to authenticated;

grant execute on function update_check_sum_total() to service_role;

