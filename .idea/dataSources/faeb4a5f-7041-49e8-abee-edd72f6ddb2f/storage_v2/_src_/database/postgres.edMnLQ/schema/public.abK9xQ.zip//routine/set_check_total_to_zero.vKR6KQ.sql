create function set_check_total_to_zero() returns trigger
    language plpgsql
as
$$
BEGIN
  -- Check if there are any sales associated with the check
  IF NOT EXISTS (
    SELECT 1
    FROM "Sale"
    WHERE check_number = NEW.check_number
  ) THEN
    -- If no sales are associated, set the sum_total to 0
    UPDATE "Check"
    SET sum_total = 0
    WHERE check_number = NEW.check_number;
  END IF;

  RETURN NEW;
END;
$$;

alter function set_check_total_to_zero() owner to postgres;

grant execute on function set_check_total_to_zero() to anon;

grant execute on function set_check_total_to_zero() to authenticated;

grant execute on function set_check_total_to_zero() to service_role;

