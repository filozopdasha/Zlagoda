create function employee_before_update_function() returns trigger
    language plpgsql
as
$$
BEGIN
  PERFORM check_age(NEW.date_of_birth);
  RETURN NEW;
END;
$$;

alter function employee_before_update_function() owner to postgres;

grant execute on function employee_before_update_function() to anon;

grant execute on function employee_before_update_function() to authenticated;

grant execute on function employee_before_update_function() to service_role;

