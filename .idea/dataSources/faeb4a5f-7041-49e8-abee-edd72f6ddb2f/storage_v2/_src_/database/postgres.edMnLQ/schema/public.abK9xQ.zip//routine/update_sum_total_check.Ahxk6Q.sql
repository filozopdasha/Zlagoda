create function update_sum_total_check() returns trigger
    language plpgsql
as
$$
DECLARE
    total NUMERIC(13, 4);
BEGIN
    -- Calculate the total sum based on selling price and number of products in Sale table
    SELECT SUM(s.selling_price * s.product_number)
    INTO total
    FROM "Sale" s
    WHERE s.check_number = NEW.check_number;

    -- Update the sum_total in Check table
    UPDATE "Check"
    SET sum_total = total
    WHERE check_number = NEW.check_number;

    RETURN NEW;
END;
$$;

alter function update_sum_total_check() owner to postgres;

grant execute on function update_sum_total_check() to anon;

grant execute on function update_sum_total_check() to authenticated;

grant execute on function update_sum_total_check() to service_role;

