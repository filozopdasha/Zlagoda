create function update_selling_price() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.promotional_product THEN
        NEW.selling_price := NEW.selling_price * 0.8;
    ELSE
        NEW.selling_price := NEW.selling_price / 0.8;
    END IF;
    RETURN NEW;
END;
$$;

alter function update_selling_price() owner to postgres;

grant execute on function update_selling_price() to anon;

grant execute on function update_selling_price() to authenticated;

grant execute on function update_selling_price() to service_role;

