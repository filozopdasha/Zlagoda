create function check_age(birthdate date) returns void
    language plpgsql
as
$$
BEGIN
  IF (CURRENT_DATE - INTERVAL '18 years' <= birthdate) THEN
    RAISE EXCEPTION 'Employee is not adult';
  END IF;
END;
$$;

alter function check_age(date) owner to postgres;

grant execute on function check_age(date) to anon;

grant execute on function check_age(date) to authenticated;

grant execute on function check_age(date) to service_role;

